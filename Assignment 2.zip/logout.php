<?php
// Written by: Chester Don Valencerina
session_start();

session_destroy();
header("location:index.php");
exit();
